module.exports = {
  plugins: {
    tailwindcss: {},
    // other plugins...
  },
};
