export function isSharedArrayBufferSupported() {

	return typeof SharedArrayBuffer !== 'undefined';

}
